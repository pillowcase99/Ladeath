/* =====================================================
   LADEATH SCRIPT.JS
   CORE SYSTEMS
===================================================== */

/* ---------------------------
   LOADER SYSTEM
--------------------------- */

window.addEventListener("load", () => {
    setTimeout(() => {
        document.getElementById("loader").style.opacity = "0";
        document.getElementById("loader").style.transition = "1.5s";

        setTimeout(() => {
            document.getElementById("loader").style.display = "none";
        }, 1500);
    }, 2000);
});

/* ---------------------------
   MUSIC SYSTEM
--------------------------- */

const music = document.getElementById("music");
const musicBtn = document.getElementById("musicButton");

let musicPlaying = false;

musicBtn.addEventListener("click", () => {
    if (!musicPlaying) {
        music.play();
        musicPlaying = true;
        musicBtn.textContent = "🔇 Mute Ambient";
    } else {
        music.pause();
        musicPlaying = false;
        musicBtn.textContent = "🔊 Ambient Music";
    }
});

/* ---------------------------
   ENTER BUTTON SCROLL
--------------------------- */

document.getElementById("enterButton").addEventListener("click", () => {
    document.getElementById("abilities").scrollIntoView({
        behavior: "smooth"
    });
});

/* ---------------------------
   POWER BAR ANIMATION
--------------------------- */

const fills = document.querySelectorAll(".fill");

const fillObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const el = entry.target;
            el.style.width = el.dataset.width;
        }
    });
}, { threshold: 0.5 });

fills.forEach(fill => fillObserver.observe(fill));

/* ---------------------------
   SCROLL REVEAL SYSTEM
--------------------------- */

const reveals = document.querySelectorAll("section");

const revealObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add("reveal");
            setTimeout(() => {
                entry.target.classList.add("active");
            }, 200);
        }
    });
}, { threshold: 0.2 });

reveals.forEach(sec => revealObserver.observe(sec));

/* ---------------------------
   CURSOR GLOW EFFECT
--------------------------- */

const cursor = document.createElement("div");
cursor.classList.add("cursor-glow");
document.body.appendChild(cursor);

document.addEventListener("mousemove", (e) => {
    cursor.style.left = e.clientX + "px";
    cursor.style.top = e.clientY + "px";
});

/* ---------------------------
   PARTICLE SYSTEM
--------------------------- */

function createParticle(className, count) {
    for (let i = 0; i < count; i++) {
        const p = document.createElement("div");
        p.className = className;

        p.style.left = Math.random() * window.innerWidth + "px";
        p.style.animationDuration = (Math.random() * 5 + 3) + "s";
        p.style.opacity = Math.random();

        document.body.appendChild(p);
    }
}

/* Ember + Snow + Smoke spawn */
createParticle("ember", 25);
createParticle("snow", 40);
createParticle("smoke", 15);
createParticle("star", 60);

/* ---------------------------
   LIGHTNING FLASH SYSTEM
--------------------------- */

const flash = document.createElement("div");
flash.classList.add("lightning");
document.body.appendChild(flash);

function lightningStrike() {
    flash.style.opacity = "0.8";

    setTimeout(() => {
        flash.style.opacity = "0";
    }, 100);
}

/* Random lightning */
setInterval(() => {
    if (Math.random() > 0.7) {
        lightningStrike();
    }
}, 4000);

/* ---------------------------
   SCREEN SHAKE (NETHER FEEL)
--------------------------- */

function screenShake() {
    document.body.style.transform = "translateX(3px)";
    setTimeout(() => {
        document.body.style.transform = "translateX(-3px)";
    }, 50);
    setTimeout(() => {
        document.body.style.transform = "translateX(0)";
    }, 100);
}

setInterval(() => {
    if (Math.random() > 0.85) {
        screenShake();
    }
}, 5000);

/* ---------------------------
   NAV LINK SMOOTH SCROLL
--------------------------- */

document.querySelectorAll("nav a").forEach(link => {
    link.addEventListener("click", (e) => {
        e.preventDefault();

        const target = document.querySelector(link.getAttribute("href"));
        if (target) {
            target.scrollIntoView({ behavior: "smooth" });
        }
    });
});

/* ---------------------------
   AUDIO AUTOPLAY ATTEMPT FIX
--------------------------- */

document.addEventListener("click", () => {
    if (musicPlaying && music.paused) {
        music.play();
    }
}, { once: true });